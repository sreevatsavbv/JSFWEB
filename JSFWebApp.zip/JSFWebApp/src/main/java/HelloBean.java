import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ValueChangeEvent;
import javax.faces.event.ValueChangeListener;
import javax.faces.model.SelectItem;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@ManagedBean(name = "helloBean")
@RequestScoped
public class HelloBean implements Serializable {
	List<SelectItem> items = new ArrayList<SelectItem>();
	String val;
	
	Strudent selectedEStudent;
	
	

	public Strudent getSelectedEStudent() {
		return selectedEStudent;
	}

	public void setSelectedEStudent(Strudent selectedEStudent) {
		this.selectedEStudent = selectedEStudent;
	}

	public List<SelectItem> getItems() {
		return items;
	}

	public void setItems(List<SelectItem> items) {
		this.items = items;
	}

	public String getVal() {
		return val;
	}

	public void setVal(String val) {
		this.val = val;
	}

	private static final long serialVersionUID = 1L;

	private String name = "Srivathsav";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public HelloBean() {
			this.name="Srivathsav";
			SelectItem item = new SelectItem();
			  item.setDescription("1");
		      item.setLabel("One");
		      item.setValue("10");
		      
		      
		      SelectItem item1 = new SelectItem();
		      item1.setDescription("2");
		      item1.setLabel("Two");
		      item1.setValue("20");
		      
		      items.add(item);
		      items.add(item1);
		      selectedEStudent = new Strudent();
		      selectedEStudent.setName("sri");
		      
	}
	
	public void onChange() {
		
		System.out.println(this.val);
		
	}
public void testChange(String val) {
		
		System.out.println(val);
		this.name="vathsav";
		
	}

public String testing() {
	
	this.name="test";
	return "test";
	
}

public void testStudent(Strudent selectStudent) {
	String name = selectedEStudent.getName();
}
	

}